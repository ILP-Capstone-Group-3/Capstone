import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UporstComponent } from './uporst.component';

describe('UporstComponent', () => {
  let component: UporstComponent;
  let fixture: ComponentFixture<UporstComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UporstComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UporstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
