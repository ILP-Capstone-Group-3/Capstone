import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uporst',
  templateUrl: './uporst.component.html',
  styleUrls: ['./uporst.component.css']
})
export class UporstComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
