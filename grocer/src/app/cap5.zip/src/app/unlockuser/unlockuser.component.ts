import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unlockuser',
  templateUrl: './unlockuser.component.html',
  styleUrls: ['./unlockuser.component.css']
})
export class UnlockuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
