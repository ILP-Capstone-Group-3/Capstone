import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { SendreqComponent } from './emp/sendreq/sendreq.component';
import { LogoutComponent } from './logout/logout.component';
import { UnlockuserComponent } from './unlockuser/unlockuser.component';
import { UporstComponent } from './uporst/uporst.component';

const routes: Routes = [

  {path:'sendreq',component:SendreqComponent  },
  {path:'uporst',component:UporstComponent  },
  {path:'unlockuser',component:UnlockuserComponent  },
  {path:'editprofile',component:EditprofileComponent  },
  {path:'logout',component:LogoutComponent  }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
